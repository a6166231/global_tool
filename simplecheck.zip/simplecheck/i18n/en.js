"use strict";module.exports={
    open_panel:"Default Panel",
    send_to_panel:"Send message to Default Panel",
    description:"Extension with a panel based on Vue3.x",
    title:"game_extend",
};