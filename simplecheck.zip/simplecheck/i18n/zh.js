"use strict";module.exports={
    extend:"游戏扩展",
    find_same_res:"查重面板",
    send_to_panel:"发送消息给面板",
    description:"含有一个基于Vue3.x开发的面板的扩展",
    open_des : "打开资源检查面板des",
    doc: "打开文件管理面板doc",
    title:"文件管理",
};