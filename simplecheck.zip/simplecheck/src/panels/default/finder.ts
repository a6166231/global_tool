import { match } from "assert";
import { Size } from "electron/main";
import Path  from "path";
import { FileUtil } from "./fileutil";
import { Opener } from "./opener";

/**
 * 查找器
 */

export class FinderData{
    name: string
    path: string
    extname: string
    uuid :string 
    fileSize :number
    md5 : string 
    constructor(name:string ,path:string,extname:string,uuid:string,fileSize:number,md5:string =""){
        this.name = name 
        this.path = path
        this.extname = extname
        this.uuid = uuid
        this.fileSize = fileSize
        this.md5 = md5
    }
}


export type PathFileMap = Map<string,FinderData>
export type MD5FileMap = Map<string,FinderData>
export class Finder
{

    /**
     * 数据缓存
     * @type {FinderData[]}
     */
    //caches :FinderData[]=  []

    caches :Map<string,FinderData> = new Map<string , FinderData>()
    
    cachesMap :Map<string,PathFileMap> = new Map<string ,PathFileMap>()

    cachesMd5Map:Map<string,PathFileMap> = new Map<string ,PathFileMap>()

    uuidcachesMap:Map<string,Map<string,string>> = new Map<string,Map<string,string>>()

    /**构造函数 */
    constructor(){

    }

    static _instance : Finder 
    static getInstance(){
        if(Finder._instance){
            return Finder._instance
        }
        Finder._instance = new Finder()
        return Finder._instance
    }
    /**
     * 清除缓存
     */
    clearCaches() {
        this.caches.clear()
        this.cachesMap.clear()
        this.uuidcachesMap.clear()
    }

    /**
     * 收集项目中的文件信息
     */
    async collectFiles(filePath = 'assets',ignore :Array<string> = ['.meta']) {
        this.caches.clear()
        this.cachesMap.clear()
        this.cachesMd5Map.clear()
        this.uuidcachesMap.clear()
        let filterMap = new Map<string,true>()
        ignore.forEach((extname,index)=>{
            filterMap.set(extname,true)
        })

        /**文件过滤 */
        const filter  =  (extname:string)=>{
            if(filterMap.has(extname)){
                return false 
            }
            return true
        }
        // 文件处理函数
        let extname:string = ''
        let name:string = ''
        let uuid:string = ''
        const handler = async (path: string, stat: any) => {       
            extname = Path.extname(path);    
            name = Path.basename(path);   
            uuid = await Opener.fspathToUuid(path)            
            if(extname=='.prefab'){               
               let uuidMap : Map<string,string> = await FileUtil.readPrefab(path)
               //console.log("path   --->",path ,uuidMap)               
               uuidMap.forEach((cuuid,_cuuid)=>{
                   let uidMap =  this.uuidcachesMap.get(cuuid)
                   if(!uidMap){
                        uidMap = new Map<string,string>()
                        this.uuidcachesMap.set(cuuid,uidMap)
                   }
                   uidMap.set(uuid,uuid)
               })
            }
            // 过滤
            if(filter(extname)){                
                //console.log("loadfile ->",name)
                const stats = await FileUtil.stat(path);   
                const md5  = await FileUtil.getFileMD5(path);          
                let data :FinderData  = new FinderData(name,path,extname,uuid,stats.size,md5)    
                let pathMap = this.cachesMap.get(data.name)                
                if(!pathMap){
                    pathMap = new Map<string,FinderData>()                    
                    this.cachesMap.set(name,pathMap)
                }
                let mdata = this.cachesMd5Map.get(md5)
                if(!mdata){
                    mdata = new Map<string,FinderData>()
                    this.cachesMd5Map.set(md5,mdata)
                }
                mdata.set(path,data)
                pathMap.set(path,data) 
                this.caches.set(data.uuid,data)
            }
        }        
        // 遍历项目文件
        const assetsPath = Path.join(Editor.Project.path, filePath);
        await FileUtil.map(assetsPath, handler);   
        return this.cachesMap
    }

    /**
     * 获取项目中匹配关键词的文件
     * @param {string} keyword 关键词
     * @returns {{ name: string, path: string, extname: string, similarity: number }[]}
     */
    getMatchedFiles(keyword: string) {
        // 处理正则公式符号
        const components = keyword.split('');
        for (let i = 0, l = components.length; i < l; i++) {
            if (/[*.?+$^()\[\]{}|\\\/]/.test(components[i])) {
                components[i] = '\\' + components[i];
            }
        }
        // 正则匹配
        // - (.*)：每个关键字之间可以有任意个字符；
        // - (?)：懒惰模式，匹配尽可能少的字符；
        // - (i)：不区分大小写；
        const pattern = components.join('.*?'),
            regExp = new RegExp(pattern, 'i');
        // 下面这行正则插入很炫酷，但是性能不好，耗时接近 split + join 的 10 倍
        // const pattern = keyword.replace(/(?<=.)(.)/g, '.*$1');
        // 查找并匹配
        const caches = this.cachesMap
        let results:any = new Map<string ,PathFileMap>()
        if (caches) {
            caches.forEach((data,name)=>{
                const match =  name.match(regExp)
                if(match){
                    results.set(name,data)
                    //const similarity = match[0].length;
                    //results.push(data)
                    //results.push({ name:name, path:data.path, extname:data.extname,similarity:similarity });
                }
            })
            // caches.forEach((data,uuid)=>{
            //     const match =  data.name.match(regExp)
            //     if(match){
            //         const similarity = match[0].length;
            //         results.push({ name:data.name, path:data.path, extname:data.extname,similarity:similarity });
            //     }
            // })

            // 排序（similarity 越小，匹配的长度越短，匹配度越高）
            // results.sort((a: { similarity: number; }, b: { similarity: number; }) =>{
            //     return a.similarity - b.similarity
            // });
        }
        return results;
    }
};