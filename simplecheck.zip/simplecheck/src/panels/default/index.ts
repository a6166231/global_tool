import { readFileSync } from 'fs-extra';
import path, { join } from 'path';
import Path from "path";
import { createApp, App } from 'vue';
import { uuid } from '../../../@types/packages/engine/@types/editor-extends/utils/uuid';
import { Finder, FinderData, MD5FileMap, PathFileMap } from './finder';
import { Opener } from './opener';
import { stringDump } from '../../../@types/packages/scene/@types/cce/utils/dump/types/string-dump';
const panelDataMap = new WeakMap<any, App>();
/**
 * @zh 如果希望兼容 3.3 之前的版本可以使用下方的代码
 * @en You can add the code below if you want compatibility with versions prior to 3.3
 */
// Editor.Panel.define = Editor.Panel.define || function(options: any) { return options }

const enum TYPE {
    FILE_MD5,
    FILE_SZE,
    FILE_NAME,
    FILE_PREFAB,
    FILE_NAME_EX,
    FILE_NAME_REG,
}

const enum STATUS {
    UNLOADING,
    LOADING,
    LOADED,
    CHECKING,
    FINISH,
}

/** 文件扩展名对应图标表 */
const ICON_MAP: { [key: string]: string } = {
    '.anim': 'animation-clip',
    '.prefab': 'prefab',
    '.fire': 'scene',
    '.scene': 'scene',
    '.effect': 'shader',
    '.mesh': 'mesh',
    '.FBX': 'mesh',
    '.mtl': 'material',
    '.pmtl': 'physics-material',
    '.pac': 'auto-atlas',
    '.ts': 'typescript',
    '.js': 'javascript',
    '.coffee': 'coffeescript',
    '.json': 'json',
    '.md': 'markdown',
    '.html': 'html',
    '.css': 'css',
    '.txt': 'text',
    '.ttf': 'ttf-font',
    '.fnt': 'bitmap-font',
    '.mp3': 'audio-clip',
    '.png': 'atlas',
    '.jpg': 'atlas',
    '.plist': 'sprite-atlas',
};

const extuuid = "@f9941"


const STATUS_INFO: { [key: number]: string } = {
    [STATUS.UNLOADING]: "未加载本地文件",
    [STATUS.LOADING]: "资源加载ing...",
    [STATUS.LOADED]: "资源加载完成",
    [STATUS.CHECKING]: "检测ing...",
    [STATUS.FINISH]: "检测完毕",
}
module.exports = Editor.Panel.define({
    listeners: {
        //show() { console.log('show'); },
        //hide() { console.log('hide'); },
    },
    template: readFileSync(join(__dirname, '../../../static/template/default/index.html'), 'utf-8'),
    style: readFileSync(join(__dirname, '../../../static/style/default/index.css'), 'utf-8'),
    $: {
        app: '#app', 
        count : '#count'
    },
    methods: {
        
    },
    async ready() {
        if (this.$.app) {
            const app = createApp({});
            app.config.compilerOptions.isCustomElement = (tag) => tag.startsWith('ui-');
            app.component('MyCounter', {
                template: readFileSync(join(__dirname, '../../../static/template/vue/counter.html'), 'utf-8'),
                data() {
                    return {
                        ignoreString : [".meta"],
                        ignoreCount : 1,
                        /**size 的Count */
                        sizeCount : 1,
                        sizeMinList : [0],
                        sizeMaxList : [100],
                        sizeListStr : "999999",
                        /**检测类型 */
                        check_mode: TYPE.FILE_NAME,
                        /**状态 */
                        status: STATUS.UNLOADING,
                        /**状态文本 */
                        statusStr: STATUS_INFO[STATUS.UNLOADING],
                        /**选择列表 */
                        check_box_list: [
                            { text: "根据MD5对比文件", id: TYPE.FILE_MD5, enable: true },
                            { text: "按照文件大小筛选", id: TYPE.FILE_SZE, enable: true },
                            { text: "按照文件名筛选", id: TYPE.FILE_NAME, enable: true },
                            { text: "按照Prefab筛选", id: TYPE.FILE_PREFAB, enable: true },                            
                            { text: "文件名查找",id: TYPE.FILE_NAME_EX, enable:true },
                            {text: "关键字查找",id: TYPE.FILE_NAME_REG, enable:true }
                        ],
                        /**loading 图标 */
                        isloading: false,
                        /**title */
                        choose_title : "",
                        /**name */
                        choose_name : "",
                        /**结果title List */
                        result_map_title: new Map<string, Map<string, PathFileMap>>(),
                        /**结果name  List*/
                        result_map_file_name: new Map<string, Array<FinderData>>(),
                        /**选中的name  list */
                        result_choose_file_map: new Map<string, FinderData>(),
                        result_choose_uuid_map: new Map<string, string[]>(),
                        /**选择的路径 */
                        result_choose_path:"",
                        /**选择资源的uuid */
                        result_choose_uuid:"",
                        /**当前场景的关联uuids */
                        result_scene_uuids:"",
                        /**当前场景的uuid */
                        result_choose_scene_uuid: "",
                        /**选中哪一个node的index */
                        focus_index : 0,
                        /**FileName */
                        file_name :"",
                    };
                }, methods: {

                    /**
                     * 获取图标
                     * @param {string} extname 扩展名
                     * @returns {string}
                     */
                    getIcon(extname: string) {
                        this.$.list.get
                        const iconName = ICON_MAP[extname] || 'asset';            
                        return `../../../images/assets/${iconName}.png`;
                    },
                    async getUUid(path: string) {
                        let uuid = await Opener.fspathToUuid(path)                        
                        return uuid
                    },

                    /**
                     * （渲染进程）聚焦文件事件回调
                     * @param {Electron.IpcMainEvent} event 
                     * @param {string} path 路径
                     */
                    async onFocusEvent(uuid: string) {
                        // 在资源管理器中显示并选中文件                       
                        Opener.focusOnFile(uuid);
                    },

                    setStatus(status: any) {
                        this.status = status
                        this.statusStr = STATUS_INFO[this.status]
                        switch (this.status) {
                            case STATUS.LOADING:
                            case STATUS.CHECKING:
                                {
                                    this.isloading = true
                                } break
                            default:
                                {
                                    this.isloading = false
                                } break
                        }
                    },

                    showBtnCheck(){
                        switch(this.status){
                            case STATUS.LOADED:
                            case STATUS.FINISH:
                                return true 
                        }
                        return false 
                    },

                    CheckShow(fileData:FinderData){
                        if(fileData.extname == ""){
                            return false 
                        }
                        for(let ext of this.ignoreString as Array<string>){
                            if(ext == fileData.extname){
                                return false
                            }                            
                        }                   
                        return true    
                    },

                    getFileNameByUuid(uuid:string){
                       let FinderData =  Finder.getInstance().caches.get(uuid)
                       return FinderData?.name??"error"
                    },

                    getFileByUuid(uuid:string){
                        let FinderData =  Finder.getInstance().caches.get(uuid)
                        return FinderData?.name??"error"
                     },

                    async find_file_byPrefab(){
                        this.result_map_file_name.clear()
                        this.result_map_title.clear()
                        const caches = Finder.getInstance().cachesMap
                        caches.forEach((PathList: PathFileMap, fileName) => {
                            if(PathList.size > 1){
                                PathList.forEach((fileData,path)=>{
                                    if(this.CheckShow(fileData)){              
                                        let finduuid = fileData.uuid
                                        let parentuuids: Map<string,string>  = this.get_parentuuid_map_by_uuid(finduuid)
                                        if(!parentuuids){
                                            finduuid = finduuid+extuuid
                                            parentuuids  = this.get_parentuuid_map_by_uuid(finduuid)
                                        }
                                        if(parentuuids?.size > 0){      
                                            parentuuids.forEach((uuid,uuid2)=>{
                                                let prefabName = this.getFileNameByUuid(uuid)
                                                let uuidMap = this.result_map_title.get(prefabName)
                                                if (!uuidMap) {
                                                    uuidMap = new Map<string, PathFileMap>()
                                                    this.result_map_title.set(prefabName, uuidMap)                                        
                                                }

                                                let nameMap : PathFileMap = uuidMap.get(fileData.extname)
                                                if(!nameMap){
                                                    nameMap = new Map<string,FinderData>()
                                                    uuidMap.set(fileData.name,nameMap)
                                                }
                                                nameMap.set(fileData.name, fileData)
                                            })                         
                                        }                                  
                                    }
                                })
                            }
                        }) 
                    },

                    async find_file_byName(isreg = false){
                        this.result_map_file_name.clear()
                        this.result_map_title.clear()
                        const caches = Finder.getInstance().cachesMap                        
                        if(isreg){
                            let file:Map<string ,PathFileMap> = Finder.getInstance().getMatchedFiles(this.file_name) 
                            if(file?.size){
                                file.forEach((fileMap, fileName) => {
                                    fileMap.forEach((fileData,path)=>{
                                        if(this.CheckShow(fileData)){                                                                              
                                            let nameMap = this.result_map_title.get(fileData.name)                                  
                                            if (!nameMap) {
                                                nameMap = new Map<string, PathFileMap>()
                                                this.result_map_title.set(fileData.name, nameMap)                                        
                                            }
                                            let extMap : PathFileMap = nameMap.get(fileData.extname)
                                            if(!extMap){
                                                extMap = new Map<string,FinderData>()
                                                nameMap.set(fileData.extname,extMap)
                                            }
                                            extMap.set(fileData.path, fileData)
                                        }
                                    })                                                                   
                                })
                            }
                        }
                        else{
                            let file  = caches.get(this.file_name)
                            if(file?.size){
                                file.forEach((fileData, fileName) => {
                                    if(this.CheckShow(fileData)){      
                                        let nameMap = this.result_map_title.get(fileData.name)                                  
                                        if (!nameMap) {
                                            nameMap = new Map<string, PathFileMap>()
                                            this.result_map_title.set(fileData.name, nameMap)                                        
                                        }
                                        let extMap : PathFileMap = nameMap.get(fileData.extname)
                                        if(!extMap){
                                            extMap = new Map<string,FinderData>()
                                            nameMap.set(fileData.extname,extMap)
                                        }
                                        extMap.set(fileData.path, fileData)
                                    }                                
                                }) 
                            }   
                        }
          
                    },

                    async find_same_byFileName() {
                        this.result_map_file_name.clear()
                        this.result_map_title.clear()
                        const caches = Finder.getInstance().cachesMap
                        caches.forEach((PathList: PathFileMap, fileName) => {
                            if(PathList.size > 1){
                                PathList.forEach((fileData,path)=>{
                                    if(this.CheckShow(fileData)){
                                        let extMap = this.result_map_title.get(fileData.extname)
                                        if (!extMap) {
                                            extMap = new Map<string, PathFileMap>()
                                            this.result_map_title.set(fileData.extname, extMap)                                        
                                        }
                                        extMap.set(fileName, PathList)                                    
                                    }
                                })
                            }
                        })                        
                    },
                    
                    IsFindFileByName(id:number){
                        return (this.check_mode == TYPE.FILE_NAME_EX && id  == TYPE.FILE_NAME_EX)
                    },

                    IsFindFileByNameReg(id:number){
                        return (this.check_mode == TYPE.FILE_NAME_REG && id  == TYPE.FILE_NAME_REG)
                    },

                    IsFindFileBySize(id:number){
                        return (this.check_mode == TYPE.FILE_SZE && id  == TYPE.FILE_SZE)
                    },

                    async find_same_byFileSize() {
                        this.result_map_file_name.clear()
                        this.result_map_title.clear()
                        let siezs = this.sizeListStr.split("|")
                        let sizeList:{[key:string]:{min:number,max:number}} = {}

                        for(let num = 0;num < this.sizeCount;num ++){
                            let key = this.sizeMinList[num] + "-" + this.sizeMaxList[num] + "kb"
                            sizeList[key] = {
                                min : this.sizeMinList[num] ,
                                max : this.sizeMaxList[num]
                            }
                            let sizeMap = new Map<string, PathFileMap>()
                            this.result_map_title.set(key,sizeMap)
                        }
                        const caches = Finder.getInstance().cachesMap
                        caches.forEach((PathList: PathFileMap, fileName) => {
                            PathList.forEach((fileData,path)=>{
                                if(this.CheckShow(fileData)){
                                    for(let key in sizeList){
                                        let data = sizeList[key]                                   
                                        if(fileData.fileSize >= data.min*1024 && fileData.fileSize <= data.max*1024){
                                            let sizeMap = this.result_map_title.get(key)                                     
                                            let nameMap : PathFileMap = sizeMap.get(fileData.name)
                                            if(!nameMap){
                                                nameMap = new Map<string,FinderData>()
                                                sizeMap.set(fileData.name,nameMap)
                                            }
                                            nameMap.set(fileData.path,fileData)                                        
                                            break
                                        }                                    
                                    }
                                }
                            })
                        })
                    },

                    async find_same_byFileMD5() {
                        this.result_map_file_name.clear()
                        this.result_map_title.clear()
                        const caches = Finder.getInstance().cachesMd5Map
                        caches.forEach((Md5List: MD5FileMap, md5str) => {
                            if(Md5List.size > 1){
                                Md5List.forEach((fileData,path)=>{
                                    if(this.CheckShow(fileData)){
                                        let extMap = this.result_map_title.get(md5str)
                                        if (!extMap) {
                                            extMap = new Map<string, PathFileMap>()
                                            this.result_map_title.set(md5str, extMap)                                        
                                        }
                                        extMap.set(fileData.name, Md5List)                                    
                                    }
                                })
                            }
                        })
                    },

                    async CheckEvent(){
                        switch(this.check_mode){
                            case TYPE.FILE_NAME:
                            {
                                await this.find_same_byFileName()
                            }break
                            case TYPE.FILE_SZE:
                            {
                                await this.find_same_byFileSize()
                            }break
                            case TYPE.FILE_MD5:
                            {
                                await this.find_same_byFileMD5()
                            }break
                            case TYPE.FILE_PREFAB:{
                                this.find_file_byPrefab()
                            }break
                            case TYPE.FILE_NAME_EX:
                            {
                                await this.find_file_byName(false)
                            }break
                            case TYPE.FILE_NAME_REG:
                            {
                                await this.find_file_byName(true)
                            }break
                        }
                    },

                    onConfirmIgnore(value: string) {               
                        this.ignoreString = value
                    },


                    onConfirmMaxSize(value: string,index:number){                                 
                       this.sizeMaxList[index-1] =Number(value)??0
                    },

                    onConfirmMinSize(value: string,index:number){                        
                        this.sizeMinList[index-1] =Number(value)??0
                    },

                    onConfirmExtName(value: string,index:number){                        
                        this.ignoreString[index-1] = value
                    },

                    onConfirmFileName(value: string){                        
                        this.file_name = value
                    },

                    ChangeSizeCount(count:number){
                        this.sizeCount = this.sizeCount + count
                        let listMin = new Array<number>()
                        let listMax = new Array<number>()
                        for(let i = 0;i < this.sizeCount ; i++){
                            listMin.push(this.sizeMinList[i]??this.sizeMaxList[i-1]??0)
                            listMax.push(this.sizeMaxList[i]??(listMin[i] + 100))
                      
                        }
                        this.sizeMinList = listMin
                        this.sizeMaxList = listMax
                    },

                    ChangeIgnoreCount(count:number){                        
                        this.ignoreCount = this.ignoreCount + count
                        let list = new Array<string>()
                        for(let i = 0;i < this.ignoreCount ; i++){
                            list.push(this.ignoreString[i])
                        }
                        this.ignoreString = list
                    },

                    onConfirm(id: any) {                        
                        if (this.CheckLoading()) {
                            return
                        }
                        this.check_mode = id
                    },

                    CheckLoading() {
                        if (this.isloading) {
                            this.error("处理ing,请耐心等待!")
                            return true
                        }
                        return false
                    },

                    async CleanCache() {
                        this.Clean()
                        Finder.getInstance().clearCaches()
                        this.setStatus(STATUS.UNLOADING)
                    },

                    Clean() {
                        if (this.CheckLoading()) {
                            return
                        }
                        this.setStatus(STATUS.LOADED)
                        this.result_map_title?.clear()
                        this.result_map_file_name?.clear()
                        this.result_choose_file_map?.clear()
                        this.result_choose_uuid_map?.clear()
                    },


                    getTitleChooseClass(TitleName:string){
                        if(this.choose_title == TitleName){
                            return "red" 
                        }
                        return "transparent red"
                    },
                    getFileNameChooseClass(FileName:string){
                        if(this.choose_name == FileName){
                            return "green" 
                        }
                        return "transparent green"
                    },
                    getpathChooseClass(title:string){

                    },

                    async LoadFile() {
                        this.setStatus(STATUS.LOADING)                  
                        await Finder.getInstance().collectFiles()
                        this.setStatus(STATUS.LOADED)
                    },    

                    async choose_same_byTitleName(title: string) {  
                        this.choose_title = title                     
                        this.result_map_file_name.clear()
                        let nameMap = this.result_map_title.get(title)
                        nameMap.forEach(async (data:PathFileMap, name:string) => {                            
                            this.result_map_file_name.set(name,data)
                        })                        
                    },

                    async choose_same_byFileName(fileName:string,PathList: PathFileMap) {
                        this.choose_name = fileName
                        this.result_choose_file_map.clear()
                        PathList.forEach(async (data, path) => {                   
                            this.result_choose_file_map.set(path, data)
                        })
                    },
                    async choose_res_file(data: FinderData) {                       
                        this.result_choose_path = data.path
                        this.result_choose_uuid = data.uuid
                        let finduuid = data.uuid
                        this.result_choose_uuid_map = this.get_parentuuid_map_by_uuid(finduuid)
                        if(!this.result_choose_uuid_map){
                            finduuid = data.uuid+extuuid
                            this.result_choose_uuid_map = this.get_parentuuid_map_by_uuid(data.uuid+extuuid)
                        }
                    },

                    async OpenSceneByuuid(uuid:string){         
                        this.result_choose_scene_uuid = uuid
                        let data = await Editor.Message.send('asset-db', 'open-asset', this.result_choose_scene_uuid);
                        this.result_scene_uuids = ""                        
                    },

                    async LoadSecenuuids(){
                        this.result_scene_uuids = await Opener.fsUuidToUseNode(this.result_choose_uuid)                     
                        await this.focuscameraByuuid(this.result_scene_uuids)                                       
                    },                    

                    async focuscameraByuuid(nodeuuids:string[]){
                        if(this.result_scene_uuids?.length > 0){
                            Editor.Selection.clear('node')
                            nodeuuids.forEach((nodeuuid,index)=>{
                                Editor.Selection.select('node',nodeuuid)                               
                            })
                            let index =  (this.focus_index++) % this.result_scene_uuids.length
                            Editor.Message.request('scene', 'focus-camera', [nodeuuids[index]]);      
                        }
                    },

                    get_parentuuid_map_by_uuid(uuid: string):Map<string,string> | undefined {      
                        return Finder.getInstance().uuidcachesMap.get(uuid)                       
                    },
                    async show(str: string) {
                        const code = await Editor.Dialog.info(str);                        
                    },
                    async error(str: string) {
                        const code = await Editor.Dialog.error(str);                      
                    },
                },
            });
            app.mount(this.$.app);
            panelDataMap.set(this, app);
        }
    },
    beforeClose() { },
    close() {
        const app = panelDataMap.get(this);
        if (app) {
            app.unmount();
        }
    },
});
