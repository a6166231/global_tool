import Path  from "path";
import { ConfigManager } from "./ConfigManager";
/**
 * 文件打开器
 */
export const  Opener ={

    // /**构造函数 */
    // constructor(){

    // }
    // static _instance : Opener 
    // static getInstance(){
    //     if(Opener._instance){
    //         return Opener._instance
    //     }
    //     Opener._instance = new Opener()
    //     return Opener._instance
    // }
    /**
     * 尝试打开文件
     * @param {string} path 路径
     */
    async tryOpen(path:string) {
        const extname = Path.extname(path),
            uuid = await this.fspathToUuid(path);
        // 是否配置了快速打开
        const { openable } :any= ConfigManager.getInstance().cache;
        if (openable.indexOf(extname) !== -1) {
            this.open(uuid);
        }
        // 聚焦到文件
        this.focusOnFile(uuid);
    },

    /**
     * 打开文件
     * @param {string} uuid Uuid
     */
    open(uuid: string) {
        Editor.Message.send('asset-db', 'open-asset', uuid);
    },

    /**
     * 聚焦到文件（在资源管理器中显示并选中文件）
     * @param {string} uuid Uuid
     */
    focusOnFile(uuid: string) {
        Editor.Selection.clear('asset');
        Editor.Selection.select('asset', [uuid]);
    },

    /**
     * 通过绝对路径获取 uuid
     * @param {string} path 路径
     * @returns {Promise<string>}
     */
    fspathToUuid(path:string) {
        return Editor.Message.request('asset-db', 'query-uuid', path);
    },

    /**
     * 找到关联uuid node
     */
    fsUuidToUseNode(uuid:string) {
        return Editor.Message.request('scene', 'query-nodes-by-asset-uuid', uuid);
    }
     
};

