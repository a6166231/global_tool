import Path  from "path";
import Fs from "fs"
import exp from "constants";

/** 配置文件路径 */
const CONFIG_PATH = Path.join(__dirname, '../../config.json');

/** package.json 的路径 */
const PACKAGE_PATH = Path.join(__dirname, '../../package.json');

/**
 * 配置缓存
 */
let configCache: null = null;

/**
 * 配置管理器
 */
export class ConfigManager {

    /**构造函数 */
    constructor(){

    }
    static _instance : ConfigManager 
    static getInstance(){
        if(ConfigManager._instance){
            return ConfigManager._instance
        }
        ConfigManager._instance = new ConfigManager()
        return ConfigManager._instance
    }       

    /**
     * 配置缓存
     */
    get cache() {
        if (!configCache) {
            this.get();
        }
        return configCache;
    }

    /**
     * 默认配置
     */
    get defaultConfig() {
        return {
            version: '1.1',
            openable: ['.scene', '.prefab'],
            autoCheckUpdate: true,
        };
    }

    /**
     * 读取配置
     */
    get() {
        const config:any = this.defaultConfig;
        // 配置
        if (Fs.existsSync(CONFIG_PATH)) {
            const localConfig = JSON.parse(Fs.readFileSync(CONFIG_PATH) as any);
            for (const key in config) {
                if (localConfig[key] !== undefined) {
                    config[key] = localConfig[key];
                }
            }
        }
        // 缓存起来
        configCache = JSON.parse(JSON.stringify(config));

        // 快捷键
        config.hotkey = this.getAccelerator();

        // Done
        return config;
    }

    /**
     * 保存配置
     * @param {*} value 配置
     */
    set(value: { [x: string]: any; hotkey: any; }) {
        const config:any = this.defaultConfig;
        // 配置
        for (const key in config) {
            if (value[key] !== undefined) {
                config[key] = value[key];
            }
        }
        Fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
        // 缓存起来
        configCache = JSON.parse(JSON.stringify(config));

        // 快捷键
        this.setAccelerator(value.hotkey);
    }

    /**
     * 获取快捷键
     * @returns {string}
     */
    getAccelerator() {
        const package2 = JSON.parse(Fs.readFileSync(PACKAGE_PATH) as any),
            item = package2['contributions']['shortcuts'][0];
        return item['win'] || '';
    }

    /**
     * 设置快捷键
     * @param {string} value 
     */
    setAccelerator(value: string | undefined) {
        const package2  = JSON.parse(Fs.readFileSync(PACKAGE_PATH) as any),
            item = package2['contributions']['shortcuts'][0];
        if (value != undefined && value !== '') {
            item['win'] = value;
            item['mac'] = value;
        } else {
            item['win'] = '';
            item['mac'] = '';
        }
        Fs.writeFileSync(PACKAGE_PATH, JSON.stringify(package2 as string, null, 2));
    }
};
