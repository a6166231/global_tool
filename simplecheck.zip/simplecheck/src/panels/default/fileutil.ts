import Fs from "fs"
import { promisify } from "util"
import Path  from "path"
import { Parser } from "./parse"
import { createHash } from "crypto"
/**
 * 文件工具 (Promise 化) 
 */
export const FileUtil = {

    /**
     * 获取文件状态
     * @param {Fs.PathLike} path 路径
     * @returns {Promise<Fs.stats>}
     */
    stat: promisify(Fs.stat),

    /**
     * 创建文件夹
     * @param {Fs.PathLike} path 路径
     * @param {Fs.MakeDirectoryOptions?} options 选项
     * @returns {Promise<void>}
     */
    mkdir: promisify(Fs.mkdir),

    /**
     * 读取文件夹
     * @param {Fs.PathLike} path 路径
     * @param {any} options 选项
     * @returns {Promise<string[]>}
     */
    readdir: promisify(Fs.readdir),

    /**
     * 移除文件夹
     * @param {Fs.PathLike} path 路径
     * @param {Fs.RmDirOptions?} options 选项
     * @returns {Promise<void>}
     */
    rmdir: promisify(Fs.rmdir),

    /**
     * 读取文件
     * @param {Fs.PathLike} path 路径
     * @param {any} options 选项
     * @returns {Promise<Buffer>}
     */
    readFile: promisify(Fs.readFile),

    /**
     * 创建文件
     * @param {Fs.PathLike} path 路径
     * @param {string | NodeJS.ArrayBufferView} data 数据
     * @param {Fs.WriteFileOptions?} options 选项
     * @returns {Promise<void>}
     */
    writeFile: promisify(Fs.writeFile),

    /**
     * 移除文件
     * @param {Fs.PathLike} path 路径
     * @returns {Promise<void>}
     */
    unlink: promisify(Fs.unlink),

    /**
     * 测试路径是否存在 (同步)
     * @param {Fs.PathLike} path 路径
     */
    existsSync: Fs.existsSync,

    /**
     * 复制文件/文件夹
     * @param {Fs.PathLike} srcPath 源路径
     * @param {Fs.PathLike} destPath 目标路径
     * @returns {Promise<boolean>}
     */
    async copy(srcPath: string, destPath: string) {
        if (!FileUtil.existsSync(srcPath)) {
            return false;
        }
        const stats = await FileUtil.stat(srcPath);
        if (stats.isDirectory()) {
            if (!FileUtil.existsSync(destPath)) {
                await FileUtil.createDir(destPath);
            }
            const names = await FileUtil.readdir(srcPath);
            for (const name of names) {
                await FileUtil.copy(Path.join(srcPath, name), Path.join(destPath, name));
            }
        } else {
            await FileUtil.writeFile(destPath, await FileUtil.readFile(srcPath));
        }
        return true;
    },

    /**
     * 创建文件夹 (递归)
     * @param {Fs.PathLike} path 路径
     * @returns {Promise<boolean>}
     */
    async createDir(path: string) {
        if (FileUtil.existsSync(path)) {
            return true;
        } else {
            const dir = Path.dirname(path);
            if (await FileUtil.createDir(dir)) {
                await FileUtil.mkdir(path);
                return true;
            }
        }
        return false;
    },

    /**
     * 移除文件/文件夹 (递归)
     * @param {Fs.PathLike} path 路径
     */
    async remove(path: string) {
        if (!FileUtil.existsSync(path)) {
            return;
        }
        const stats = await FileUtil.stat(path);
        if (stats.isDirectory()) {
            const names = await FileUtil.readdir(path);
            for (const name of names) {
                await FileUtil.remove(Path.join(path, name));
            }
            await FileUtil.rmdir(path);
        } else {
            await FileUtil.unlink(path);
        }
    },

    /**
     * 遍历文件/文件夹并执行函数
     * @param {Fs.PathLike} path 路径
     * @param {(filePath: Fs.PathLike, stat: Fs.Stats) => void | Promise<void>} handler 处理函数
     */
    async map(path: string, handler: (arg0: any, arg1: any) => any) {
        if (!FileUtil.existsSync(path)) {
            return;
        }
        const stats = await FileUtil.stat(path);
        if (stats.isDirectory()) {
            const names = await FileUtil.readdir(path);
            for (const name of names) {
                await FileUtil.map(Path.join(path, name), handler);
            }
        } else {
           await handler(path, stats);
        }
    },


    getNodePathByUidInTree(tree:any,npath = new  Map<string,string>()) {       
        if (!tree) return npath;
        for (let children of tree.children) {
            let uuids = this.containsValue(children.components, '__uuid__');
            if (uuids?.length > 0 ) {
                uuids.forEach((uuid,index)=>{
                    npath.set(uuid,uuid)
                })               
            }
            this.getNodePathByUidInTree(children,npath)
        }
        return npath;
    },
    
    containsValue (object : any, value :any) {
        let result: any[] = [];
        const search = (_object:any) => {
            if (Parser.isObject(_object)) {
                for (const key in _object) {
                    if (key === value) {
                        result.push(_object[key])
                        //result = _object[key];
                        //return;
                    }
                    search(_object[key]);
                }
            } else if (Array.isArray(_object)) {
                for (let i = 0, l = _object.length; i < l; i++) {
                    search(_object[i]);
                }
            }
        }
        search(object);
        return result;
    },

    /**读取 prefab */
    async readPrefab(prefabPath:string){
        return new Promise<Map<string,string>>((resolve, reject) => {
            Fs.readFile(prefabPath, 'utf8', (err, data) => {
                resolve(this.getNodePathByUidInTree(Parser.convert(JSON.parse(data))))
            })
        })
    },

    async getFileMD5(filePath: string): Promise<string> {
        return new Promise((resolve, reject) => {
            const hash = createHash('md5'); // 创建 md5 对象            
            try {
                const stream = Fs.createReadStream(filePath); // 读取文件流
                
                stream.on('data', chunk => {
                    hash.update(chunk); // 更新 md5 值
                });
                
                stream.on('end', () => {
                    resolve(hash.digest('hex')); // 返回十六进制格式的 md5 值
                });
                
                stream.on('error', err => {
                    reject(err);
                });
            } catch (e) {
                reject(e);
            }
        });
    }
};

